﻿using LogComponent.Domain.Enums;
using Microsoft.Extensions.Configuration;

namespace CommonUtils
{
    public static class LogConfiguration
    {
        /// <summary>
        /// Return logger if already exist or create new one
        /// </summary>
        /// <param name="logLevel"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>

        public static IDictionary<LogLevel, LogTarget> LoadInStoreConfiguration(IConfiguration configuration)
        {
            var instoreConfiguration = new Dictionary<LogLevel, LogTarget>();
            var logComponent = configuration.GetSection("LogComponent");
            var fatal = logComponent.GetValue<string>("FATAL");
            var logFatal = (LogTarget)Enum.Parse(typeof(LogTarget), fatal);
            instoreConfiguration.Add(LogLevel.FATAL, logFatal);

            var error = logComponent.GetValue<string>("ERROR");
            var logError = (LogTarget)Enum.Parse(typeof(LogTarget), error);
            instoreConfiguration.Add(LogLevel.ERROR, logError);

            var warn = logComponent.GetValue<string>("WARN");
            var logWarn = (LogTarget)Enum.Parse(typeof(LogTarget), warn);
            instoreConfiguration.Add(LogLevel.WARN, logWarn);

            var info = logComponent.GetValue<string>("INFO");
            var logInfo = (LogTarget)Enum.Parse(typeof(LogTarget), info);
            instoreConfiguration.Add(LogLevel.INFO, logInfo);

            var debug = logComponent.GetValue<string>("DEBUG");
            var logDebug = (LogTarget)Enum.Parse(typeof(LogTarget), debug);
            instoreConfiguration.Add(LogLevel.DEBUG, logDebug);
            return instoreConfiguration;
        }
        public static string GetConnectionString(IConfiguration configuration)
        {
            var connectionStrings = configuration.GetSection("ConnectionStrings");
            return connectionStrings.GetValue<string>("DefaultConnection");
        }
               
    }
}
