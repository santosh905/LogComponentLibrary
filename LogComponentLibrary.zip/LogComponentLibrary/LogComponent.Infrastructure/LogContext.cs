﻿using LogComponent.Domain.Entities;
using LogComponent.Domain.Repositories;
using LogComponent.Infrastructure.SchemaDefnitions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LogComponent.Infrastructure
{
    public class LogContext : DbContext, IUnitOfWork
    {
        public const string DEFAULT_SCHEMA = "LogItem";
        private IConfiguration? _configuration;
        private string connectionString = string.Empty;
        public DbSet<LogItem> LogItems { get; set; }

        public LogContext(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = configuration.GetSection("ConnectionStrings:DefaultConnection").Value;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=storelog;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
            optionsBuilder.UseSqlServer(connectionString);
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new LogItemEntitySchemaDefinition());
            base.OnModelCreating(modelBuilder);
        }

        public async Task<bool> SaveEntitiesAsync(CancellationToken
            cancellationToken = default(CancellationToken))
        {
            await SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}
