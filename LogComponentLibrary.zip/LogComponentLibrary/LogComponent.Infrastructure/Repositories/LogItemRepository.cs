﻿using LogComponent.Domain.Entities;
using LogComponent.Domain.Repositories;
using System.Diagnostics;

namespace LogComponent.Infrastructure.Repositories
{
    public class LogItemRepository : ILogItemRepository
    {
        private readonly LogContext _context;
        private EventLog eventLog = new();
        public IUnitOfWork UnitOfWork => (IUnitOfWork)_context;

        public LogItemRepository(LogContext context)
        {
            _context = context ?? throw new
             ArgumentNullException(nameof(context));
        }

        public LogItem Add(LogItem item)
        {
            try
            {
               return  _context.LogItems
                .Add(item).Entity;
                
            }
            catch (Exception ex)
            {
                eventLog.WriteEntry(ex.Message, EventLogEntryType.Error);
                return null;
            }
        }

    }
}
