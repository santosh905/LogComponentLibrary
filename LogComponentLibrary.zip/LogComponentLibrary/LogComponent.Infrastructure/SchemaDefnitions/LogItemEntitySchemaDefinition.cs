﻿using LogComponent.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LogComponent.Infrastructure.SchemaDefnitions
{
    public class LogItemEntitySchemaDefinition : IEntityTypeConfiguration<LogItem>
    {
        public void Configure(EntityTypeBuilder<LogItem> builder)
        {
            builder.HasKey(k => k.Id);
            builder.Property(p => p.LogLevel).IsRequired();
            builder.Property(p => p.Message).IsRequired().HasMaxLength(500);
            builder.Property(p => p.MemberName).IsRequired().HasMaxLength(50);
        }
    }
}
