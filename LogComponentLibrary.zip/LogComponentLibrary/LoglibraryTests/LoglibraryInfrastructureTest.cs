﻿using FluentAssertions;
using LogComponent.Domain.Entities;
using LogComponent.Domain.Enums;
using LogComponent.Domain.Repositories;
using LogComponent.Infrastructure;
using LogComponent.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoglibraryTests
{
    public class LoglibraryInfrastructureTest
    {
        ILogItemRepository logItemRepository = null;
        public LoglibraryInfrastructureTest()
        {
            IConfiguration configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: false)
            .Build();
            logItemRepository = new LogItemRepository(new LogContext(configuration));
        }
        [Fact]
        public async Task LoglibraryInfrastructureTest_WriteLogs_NoError()
        {
            var log = new LogItem
            {
                LogLevel = LogLevel.ERROR,
                Message = "test save database",
                MemberName = "Test"
            };

            logItemRepository.Add(log);
            var result = await logItemRepository.UnitOfWork.SaveEntitiesAsync();
            result.Should().BeTrue();
        }    
    }
}
