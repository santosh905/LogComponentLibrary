using LogComponent;
using LogComponent.Domain.Enums;

namespace LoglibraryTests
{
    public class LoglibraryConfigurationTest
    {
        [Fact]
        public void Loglibrary_WriteLog_FATAL()
        {
            try
            {
                Logger.Instance.Log(LogLevel.FATAL, "this is the FATAL log message");
                Assert.True(true);
            }
            catch(Exception ex)
            { 
                Assert.Fail(ex.ToString());
            }
        }
        [Fact]
        public void Loglibrary_WriteLog_Error()
        {
            try
            {
                Logger.Instance.Log(LogLevel.ERROR, "this is the Error log message");
                Assert.True(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.ToString());
            }
        }

        [Fact]
        public void Loglibrary_WriteLog_Debug()
        {
            try
            {
                Logger.Instance.Log(LogLevel.DEBUG, "this is the Debug log message");
                Assert.True(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.ToString());
            }
        }
        [Fact]
        public void Loglibrary_WriteLog_Warn()
        {
            try
            {
                Logger.Instance.Log(LogLevel.WARN, "this is the Warn log message");
                Assert.True(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.ToString());
            }
        }
        [Fact]
        public void Loglibrary_WriteLog_Info()
        {
            try
            {
                Logger.Instance.Log(LogLevel.INFO, "this is the Info log message");
                Assert.True(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.ToString());
            }
        }
    }
}