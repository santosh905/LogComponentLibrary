﻿using System.Runtime.CompilerServices;
using LogComponent.Domain.Enums;

namespace LogComponent
{
    public interface ILogger
    {
        void Log(LogLevel logLevel, string message, [CallerMemberName] string memberName = "");
    }
}