﻿using LogComponent.Domain.Enums;
using System.Runtime.CompilerServices;


namespace LogComponent
{
    public class Consolelogger : ILogger
    {
        public void Log(LogLevel logLevel, string message, [CallerMemberName] string memberName = "")
        {
            Console.WriteLine($" logLevel:{logLevel} || message:{message} || memberName: {memberName} ");
        }
    }
}
