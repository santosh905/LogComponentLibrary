﻿using System.Runtime.CompilerServices;
using LogComponent.Domain.Enums;
using Microsoft.Extensions.Configuration;

namespace LogComponent
{
    public class FileLogger : ILogger
    {
        public string filePath = string.Empty;
        public IConfiguration? configuration = null;

        public FileLogger(IConfiguration configuration)
        {
            filePath = configuration.GetSection("LogPath").GetValue<string>("path");
        }
        public void Log(LogLevel logLevel, string message, [CallerMemberName] string memberName = "")
        {
            using (StreamWriter streamWriter = new StreamWriter(filePath,true))
            {
                streamWriter.WriteLine($"loglevel:{logLevel.ToString()} || message:{message} || memberName:{memberName} ");
                streamWriter.Close();
            }
        }
    }
}
