﻿using System.Runtime.CompilerServices;
using CommonUtils;
using LogComponent.Domain.Enums;
using Microsoft.Extensions.Configuration;

namespace LogComponent
{
    public class Logger
    {
        #region Private members

        private static Logger? logger = null;
        private static readonly object lockobj = new object();
        private readonly IList<ILogger> inStoreLogger;
        private IConfiguration configuration;

        #endregion
        internal IDictionary<LogLevel, LogTarget> InstoreConfiguration { get; private set; }

        private Logger()
        {
            configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: false)
            .Build();
            InstoreConfiguration = LogConfiguration.LoadInStoreConfiguration(configuration);
            inStoreLogger = new List<ILogger>();
        }

        public static Logger Instance
        {
            get
            {
                lock(lockobj)
                {
                    if(logger == null) 
                    { 
                        return new Logger();
                    }
                }
                return logger;
            }
        }


        /// <summary>
        /// log with messages
        /// </summary>
        /// <optionalparam>default value loglevel = LogLevel.INFO </optionalparam>
        /// <param name="message"></param>
        /// <optionalparam>default value membername equals to nameof(LoggerProvider) </optionalparam>
        public void Log(string message)
        {
            Log(LogLevel.INFO, message);
        }
        /// <summary>
        /// log message with loglevel and messages
        /// </summary>
        /// <param name="logLevel"></param>
        /// <param name="message"></param>
        /// <optionalparam>default value membername equals to nameof(LoggerProvider) </optionalparam>
        public void Log(LogLevel logLevel, string message)
        {
            Log(logLevel, message, nameof(Logger));
        }
        /// <summary>
        /// log message with loglevel, messages and membername
        /// </summary>
        /// <param name="logLevel"></param>
        /// <param name="message"></param>
        /// <param name="membername"></param>
        public void Log(LogLevel logLevel, string message, [CallerMemberName] string membername = "")
        {
          LoggerFactory.CreateOrReturnLogger(logLevel,InstoreConfiguration, inStoreLogger, configuration).Log(logLevel, message, membername);
        }
        
    }
}
