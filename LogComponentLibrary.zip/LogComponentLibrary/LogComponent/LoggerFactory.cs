﻿using LogComponent.Domain.Enums;
using Microsoft.Extensions.Configuration;

namespace LogComponent
{
    public static class LoggerFactory
    {
        public static ILogger CreateOrReturnLogger(LogLevel logLevel, IDictionary<LogLevel, LogTarget> InstoreConfiguration, IList<ILogger>inStoreLogger, IConfiguration configuration)
        {
            InstoreConfiguration.TryGetValue(logLevel, out LogTarget logtype);
            switch (logtype)
            {
                case LogTarget.file:
                    {
                        foreach (var logger in inStoreLogger)
                        {
                            if (logger is FileLogger fileLogger)
                            {
                                return fileLogger;
                            }
                        }

                        var result = new FileLogger(configuration);
                        inStoreLogger.Add(result);
                        return result;
                    }
                case LogTarget.console:
                    {
                        foreach (var logger in inStoreLogger)
                        {
                            if (logger is Consolelogger consolelogger)
                            {
                                return consolelogger;
                            }
                        }
                        var result = new Consolelogger();
                        inStoreLogger.Add(result);
                        return result;
                    }
                case LogTarget.database:
                    {
                        foreach (var logger in inStoreLogger)
                        {
                            if (logger is Dblogger dblogger)
                            {
                                return dblogger;
                            }
                        }
                        var result = new Dblogger(configuration);
                        inStoreLogger.Add(result);
                        return result;
                    }
                default:
                    {
                        throw new NotImplementedException();
                    }
            }
        }
    }
}
