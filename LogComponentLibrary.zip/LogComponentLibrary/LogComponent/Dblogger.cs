﻿using System.Runtime.CompilerServices;
using LogComponent.Domain.Entities;
using LogComponent.Domain.Enums;
using LogComponent.Domain.Repositories;
using LogComponent.Infrastructure;
using LogComponent.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;

namespace LogComponent
{
    public class Dblogger : ILogger
    {
        private readonly IConfiguration? _configuration = null;
        private readonly ILogItemRepository? repository = null;
        public Dblogger(IConfiguration configuration)
        {
            configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            repository = new LogItemRepository(new LogContext(configuration));
        }
        public void Log(LogLevel logLevel, string message, [CallerMemberName] string memberName = "")
        {
            var log = new LogItem
            {
                LogLevel = logLevel,
                Message = message,
                MemberName = memberName
            };
            repository.Add(log);
            repository.UnitOfWork.SaveEntitiesAsync();
        }
    }
}
