﻿using LogComponent.Domain.Entities;
using LogComponent.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogComponent.Domain.services
{
    public class LogItemService : ILogItemService
    {
        private readonly ILogItemRepository? logItemRepository;
        private EventLog eventLog = new();
        public LogItemService(ILogItemRepository logItemRepository)
        {
            if (logItemRepository == null) throw new ArgumentNullException(nameof(logItemRepository));
            this.logItemRepository = logItemRepository;
        }

       public bool AddLogItemAsync(LogItem request)
        {
            try
            {
                if (request == null) throw new ArgumentNullException(nameof(request));
                this.logItemRepository.Add(request); return true;
            }
            catch (Exception ex)
            {
                eventLog.WriteEntry(ex.Message, EventLogEntryType.Error);
                return false;
            }
        }
    }
}
