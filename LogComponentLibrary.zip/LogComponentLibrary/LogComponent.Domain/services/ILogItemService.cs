﻿using LogComponent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogComponent.Domain.services
{
    public interface ILogItemService
    {
        bool AddLogItemAsync(LogItem request);
    }
}
