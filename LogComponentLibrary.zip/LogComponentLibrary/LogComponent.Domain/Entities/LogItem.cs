﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogComponent.Domain.Enums;
using System.Diagnostics.Tracing;

namespace LogComponent.Domain.Entities
{
    public class LogItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [field: NonSerialized]
        public int Id { get; set; }
        public LogLevel LogLevel { get; set; }
        public string Message { get; set; }
        public string MemberName { get; set; }
    }
}
