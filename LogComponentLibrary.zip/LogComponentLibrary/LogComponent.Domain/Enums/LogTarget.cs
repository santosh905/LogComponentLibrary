﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogComponent.Domain.Enums
{
    public enum LogTarget
    {
        file,
        console,
        database
    }
}
